package com.charitylink.app.data

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

/** Defines the HTTP endpoints exposed by the CharityLink backend. */
interface ApiService {

    @POST("api/auth/login")
    suspend fun login(@Body body: LoginRequest): AuthResponse

    @POST("api/auth/register")
    suspend fun register(@Body body: RegisterRequest): AuthResponse

    @GET("api/campaigns")
    suspend fun getCampaigns(): List<Campaign>

    @POST("api/campaigns/{id}/donate")
    suspend fun donate(
        @Path("id") id: Int,
        @Body body: DonateRequest
    ): DonateResponse

    @GET("api/users/{email}/contributions")
    suspend fun getContributions(
        @Path("email") email: String
    ): List<Contribution>

    @POST("api/ai/impact")
    suspend fun getImpact(@Body body: ImpactRequest): ImpactResponse
}

/** Shared Retrofit client used by the app's ViewModel. */
object ApiClient {

    // 10.0.2.2 points to the development computer from the Android emulator.
    // For a physical phone, replace this with the computer's LAN IP address.
    private const val BASE_URL = "http://10.0.2.2:3000/"

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        // BODY is useful while developing; avoid shipping verbose logging in production.
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .build()

    val api: ApiService = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(ApiService::class.java)
}
